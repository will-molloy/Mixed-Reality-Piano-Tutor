#ifndef GEO_CONFIG_H
#define GEO_CONFIG_H

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H

/* Define if you have the <strings.h> header file.  */
#define HAVE_STRING_H

#endif /* ndef GEO_CONFIG_H */
